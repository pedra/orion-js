const VERSION = '2003182214'
const FILES = [
	'/',

	// Opcional manifest files ------
	// '/icon/site.json',
	// '/icon/favicon.ico',
	// '/favicon.ico',
	// '/icon/favicon-16x16.png',
	// '/icon/favicon-32x32.png',
	// '/icon/android-chrome-192x192.png',
	// '/icon/android-chrome-512x512.png',
	// '/icon/apple-touch-icon.png',
	// '/icon/safari-pinned-tab.svg',

	'js/vendor/rsa.js',
	'js/vendor/aes.js',
	'/js/gate.js'
]
